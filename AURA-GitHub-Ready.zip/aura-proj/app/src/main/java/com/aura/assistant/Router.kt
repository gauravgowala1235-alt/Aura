package com.aura.assistant

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.Settings
import androidx.core.app.NotificationCompat
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

sealed interface Reply {
    data class Say(val text: String) : Reply
    /** Sensitive action: the service speaks [prompt], waits for a spoken yes, and only then runs [run]. */
    data class Confirm(val prompt: String, val run: () -> String) : Reply
}

/** Local-first command router: handles supported actions on-device, falls back to cloud AI for everything else. */
class Router(private val ctx: Context, private val p: Prefs) {
    private val timeRx = Regex("""(\d{1,2})(?::(\d{2}))?\s?(am|pm)""")
    private fun say(s: String) = Reply.Say(s)

    suspend fun route(raw: String): Reply {
        val t = raw.lowercase().replace(Regex("""\b([ap])\.m\.?"""), "$1m").trim()
        Regex("""(\d+(?:\.\d+)?)\s?(?:percent|%) of (\d+(?:\.\d+)?)""").find(t)?.let {
            val r = it.groupValues[1].toDouble() * it.groupValues[2].toDouble() / 100
            return say("That is ${"%.2f".format(Locale.US, r).trimEnd('0').trimEnd('.')}.")
        }
        return when {
            Regex("""\bdate\b""").containsMatchIn(t) -> say("Today is ${LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy"))}.")
            "what time" in t || "the time" in t -> say("It is ${LocalTime.now().format(DateTimeFormatter.ofPattern("h:mm a"))}.")
            "timer" in t -> Regex("""(\d+)\s?(second|minute|hour)""").find(t)?.let { m ->
                val n = m.groupValues[1].toInt() * when (m.groupValues[2]) { "hour" -> 3600; "minute" -> 60; else -> 1 }
                go(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, n).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
                say("Timer started for ${m.groupValues[1]} ${m.groupValues[2]}s.")
            } ?: say("For how long?")
            "alarm" in t || "remind" in t -> alarm(t)
            t.startsWith("open ") -> open(t.removePrefix("open ").removePrefix("my ").trim())
            "volume" in t -> {
                val up = Regex("increase|raise|up|louder").containsMatchIn(t)
                ctx.getSystemService(AudioManager::class.java).adjustStreamVolume(
                    AudioManager.STREAM_MUSIC, if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                say("Done.")
            }
            "brightness" in t -> {
                val up = Regex("increase|raise|up|brighter").containsMatchIn(t)
                Reply.Confirm("Shall I ${if (up) "increase" else "decrease"} the brightness?") {
                    if (!Settings.System.canWrite(ctx)) {
                        go(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}")))
                        "I need the modify system settings permission first. I've opened it."
                    } else {
                        val cur = Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128)
                        Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, (cur + if (up) 40 else -40).coerceIn(10, 255))
                        "Brightness adjusted."
                    }
                }
            }
            "bluetooth" in t -> {
                go(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
                say("Android doesn't let apps switch Bluetooth on silently. I've opened Bluetooth settings.")
            }
            "recent" in t -> say("Android doesn't let apps open the recent tasks screen. Swipe up and hold to view it.")
            else -> say(Ai.ask(p, raw, Regex("^(explain|help|summar|why|how|what is)").containsMatchIn(t)))
        }
    }

    private fun alarm(t: String): Reply {
        val m = timeRx.find(t) ?: return say("What time should I set it for?")
        val h = m.groupValues[1].toInt() % 12 + if (m.groupValues[3] == "pm") 12 else 0
        val min = m.groupValues[2].ifEmpty { "0" }.toInt()
        val label = Regex("""remind me to (.+?) at""").find(t)?.groupValues?.get(1) ?: "AURA"
        go(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, min)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
        return say("Done. I've scheduled it for ${m.value.uppercase()}.")
    }

    private fun open(name: String): Reply {
        val pm = ctx.packageManager
        val app = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .firstOrNull { name in it.loadLabel(pm).toString().lowercase() } ?: return say("I couldn't find an app called $name.")
        val i = pm.getLaunchIntentForPackage(app.activityInfo.packageName) ?: return say("I can't launch that.")
        go(i)
        return say("Opening ${app.loadLabel(pm)}.")
    }

    /** Android blocks activity launches from the background. With "display over other apps" granted we launch
     *  directly; otherwise we post a tap-to-continue notification instead of pretending it worked. */
    private fun go(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Settings.canDrawOverlays(ctx)) { ctx.startActivity(i); return }
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("act", "AURA actions", NotificationManager.IMPORTANCE_HIGH))
        nm.notify(2, NotificationCompat.Builder(ctx, "act").setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("AURA").setContentText("Tap to continue").setAutoCancel(true)
            .setContentIntent(PendingIntent.getActivity(ctx, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)).build())
    }
}
