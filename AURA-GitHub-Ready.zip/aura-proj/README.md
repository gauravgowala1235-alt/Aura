# AURA (Android tablet assistant)

Build: open this folder in Android Studio (Koala or newer, JDK 17) -> let Gradle sync (it creates the wrapper) -> Run on a tablet (Android 8+, USB debugging on).
CLI: `gradle wrapper && ./gradlew assembleDebug`.

First run: Settings -> add API key (or your HTTPS proxy URL) -> Back -> Start AURA -> grant microphone and notifications.
Also grant, from Settings: "Allow opening apps from the background" (needed for Open/Alarm/Timer while AURA is not on screen) and Battery optimisation.
After a reboot or force-stop, reopen the app and tap Start AURA; Android 14+ does not allow mic services to auto-start.

Wake word: SttWakeWord loops the on-device recogniser (Android 13+) and matches your phrase. It is the portable baseline;
for low-power, fully local detection implement WakeWordEngine with Porcupine or openWakeWord.
Known limits: some devices beep on each recogniser restart; with no on-device recogniser, Google's service may process wake audio.

## Build the APK without installing anything (GitHub)
1. Create a free GitHub repo and upload the contents of this folder to its root (keep the hidden .github folder).
2. Open the repo's Actions tab -> "Build AURA APK" -> Run workflow (it also runs on every push).
3. When it turns green (about 5 minutes), open the run and download the `aura-debug-apk` artifact. Unzip it.
4. Copy app-debug.apk to the tablet, open it, and allow "install unknown apps" when asked.
