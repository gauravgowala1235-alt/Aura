package com.aura.assistant

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.*

/** Foreground service (type: microphone). Pipeline: wake word -> STT -> router/AI -> action -> TTS -> standby. */
class AuraService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var job: Job? = null
    private var tts: Tts? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, id: Int): Int {
        if (i?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("svc", "AURA standby", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0, Intent(this, AuraService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(this, "svc").setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("AURA is on standby").setContentText("Listening for your wake phrase")
            .setOngoing(true).addAction(0, "Stop", stop).build()
        try {
            ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } catch (e: Exception) { // mic permission missing, or Android refused a background start
            stopSelf(); return START_NOT_STICKY
        }
        AuraBus.running.value = true
        if (job == null) job = scope.launch { loop() }
        return START_NOT_STICKY // Android 14+ forbids restarting a mic service from the background
    }

    private suspend fun loop() {
        val p = Prefs(this)
        val stt = Stt(this)
        val wake: WakeWordEngine = SttWakeWord(stt, p)
        val router = Router(this, p)
        val voice = Tts(this, p.s("lang", "en-IN")).also { tts = it }
        suspend fun reply(s: String) { AuraBus.state.value = AuraState.RESPONDING; AuraBus.add("AURA: $s"); voice.say(s) }

        while (currentCoroutineContext().isActive) {
            AuraBus.state.value = AuraState.STANDBY
            var cmd: String? = wake.await() ?: continue
            if (cmd.isNullOrEmpty()) {
                reply("Yes. I'm listening.")
                AuraBus.state.value = AuraState.LISTENING
                cmd = stt.listen(p.s("lang", "en-IN"))?.trim()
            }
            if (cmd.isNullOrBlank()) { reply("I didn't catch that."); continue }
            AuraBus.add("YOU: $cmd")
            AuraBus.state.value = AuraState.THINKING
            val r = try { router.route(cmd) } catch (e: Exception) { Reply.Say("Something went wrong.") }
            when (r) {
                is Reply.Say -> reply(r.text)
                is Reply.Confirm -> {
                    reply(r.prompt)
                    AuraBus.state.value = AuraState.LISTENING
                    val a = stt.listen(p.s("lang", "en-IN"))?.lowercase().orEmpty()
                    reply(if (Regex("\\b(yes|yeah|confirm|proceed|do it)\\b").containsMatchIn(a)) r.run() else "Cancelled.")
                }
            }
        }
    }

    override fun onDestroy() {
        scope.cancel(); tts?.shutdown()
        AuraBus.running.value = false; AuraBus.state.value = AuraState.STANDBY
        super.onDestroy()
    }
}
