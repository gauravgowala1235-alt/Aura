package com.aura.assistant

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Cloud reasoning layer. Sends only the recognised command text (never audio), HTTPS only.
 *  For production, point apiUrl at your own backend proxy instead of shipping an API key on the device. */
object Ai {
    suspend fun ask(p: Prefs, q: String, detailed: Boolean): String = withContext(Dispatchers.IO) {
        val key = p.s("apiKey")
        val url = p.s("apiUrl", "https://api.anthropic.com/v1/messages")
        if (key.isBlank()) return@withContext "Cloud AI isn't set up yet. Add an API key in settings."
        if (!url.startsWith("https://")) return@withContext "The AI endpoint must use HTTPS."
        val mem = if (p.b("memory")) " The user's name is ${p.s("name")}. They study ${p.s("subjects")}." else ""
        val sys = "You are AURA, a calm, professional voice assistant. Reply in plain spoken English, no markdown. " +
            (if (detailed) "Explain clearly in under 120 words." else "Answer in under 25 words.") + mem
        val body = JSONObject().put("model", p.s("model", "claude-sonnet-5-5")).put("max_tokens", 400).put("system", sys)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", q)))
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"; c.connectTimeout = 8000; c.readTimeout = 20000; c.doOutput = true
            c.setRequestProperty("content-type", "application/json")
            c.setRequestProperty("x-api-key", key)
            c.setRequestProperty("anthropic-version", "2023-06-01")
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            if (c.responseCode in 200..299)
                JSONObject(c.inputStream.bufferedReader().readText()).getJSONArray("content").getJSONObject(0).getString("text")
            else "The AI service returned error ${c.responseCode}."
        } catch (e: Exception) {
            "I couldn't reach the AI service."
        } finally { c.disconnect() }
    }
}
