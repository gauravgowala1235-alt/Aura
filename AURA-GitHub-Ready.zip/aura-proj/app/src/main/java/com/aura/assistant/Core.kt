package com.aura.assistant

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow

enum class AuraState(val label: String) {
    STANDBY("STANDBY"), LISTENING("LISTENING"), THINKING("PROCESSING REQUEST"), RESPONDING("RESPONDING")
}

/** Shared state between the service (pipeline) and the Compose UI. Command log lives in RAM only. */
object AuraBus {
    val state = MutableStateFlow(AuraState.STANDBY)
    val level = MutableStateFlow(0f)
    val running = MutableStateFlow(false)
    val log = MutableStateFlow<List<String>>(emptyList())
    fun add(line: String) { log.value = (log.value + line).takeLast(8) }
}

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("aura", Context.MODE_PRIVATE)
    fun s(k: String, d: String = ""): String = sp.getString(k, null)?.ifBlank { d } ?: d
    fun b(k: String) = sp.getBoolean(k, false)
    fun put(k: String, v: Any) {
        sp.edit().also { if (v is Boolean) it.putBoolean(k, v) else it.putString(k, v.toString()) }.apply()
    }
    fun clearMemory() { sp.edit().remove("name").remove("subjects").apply() }
}
