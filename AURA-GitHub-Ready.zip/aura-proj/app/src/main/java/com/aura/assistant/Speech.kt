package com.aura.assistant

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.Locale
import kotlin.coroutines.resume

/** One-shot speech-to-text. Must be called on the main thread. Prefers the on-device recogniser. */
class Stt(private val ctx: Context) {
    private fun make(): SpeechRecognizer =
        if (Build.VERSION.SDK_INT >= 33 && SpeechRecognizer.isOnDeviceRecognitionAvailable(ctx))
            SpeechRecognizer.createOnDeviceSpeechRecognizer(ctx)
        else SpeechRecognizer.createSpeechRecognizer(ctx)

    suspend fun listen(lang: String): String? = suspendCancellableCoroutine { c ->
        val r = make()
        fun finish(v: String?) { r.destroy(); if (c.isActive) c.resume(v) }
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(b: Bundle?) =
                finish(b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull())
            override fun onError(e: Int) = finish(null)
            override fun onRmsChanged(v: Float) { AuraBus.level.value = ((v + 2f) / 12f).coerceIn(0f, 1f) }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, b: Bundle?) {}
        })
        r.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
                .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        )
        c.invokeOnCancellation { r.destroy() }
    }
}

/** Swap point: replace with Porcupine / openWakeWord for low-power, fully local detection. */
interface WakeWordEngine {
    /** Returns null if no wake phrase was heard, otherwise whatever was said after it (may be empty). */
    suspend fun await(): String?
}

class SttWakeWord(private val stt: Stt, private val p: Prefs) : WakeWordEngine {
    override suspend fun await(): String? {
        val heard = stt.listen(p.s("lang", "en-IN"))?.lowercase()
        delay(if (heard == null) 800 else 150) // back off on silence/errors to save battery
        val wake = p.s("wake", "hey aura").lowercase()
        return if (heard != null && wake in heard) heard.substringAfter(wake).trim(' ', ',', '.') else null
    }
}

class Tts(ctx: Context, lang: String) {
    private var tts: TextToSpeech? = null
    private var ok = false

    init {
        tts = TextToSpeech(ctx) { s ->
            ok = s == TextToSpeech.SUCCESS
            if (ok) tts?.apply { language = Locale.forLanguageTag(lang); setPitch(0.85f); setSpeechRate(0.95f) }
        }
    }

    suspend fun say(text: String) = suspendCancellableCoroutine<Unit> { c ->
        val t = tts
        if (t == null || !ok) { c.resume(Unit); return@suspendCancellableCoroutine }
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(u: String?) {}
            override fun onDone(u: String?) { if (c.isActive) c.resume(Unit) }
            @Deprecated("Deprecated in Java")
            override fun onError(u: String?) { if (c.isActive) c.resume(Unit) }
        })
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "aura")
        c.invokeOnCancellation { t.stop() }
    }

    fun shutdown() { tts?.shutdown() }
}
