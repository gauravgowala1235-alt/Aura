package com.aura.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.delay
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

val Cyan = Color(0xFF22D3EE)
val Ink = Color(0xFF050608)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Ink, surface = Ink)) { AuraApp() } }
    }
}

@Composable
fun Glass(mod: Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Column(mod.clip(shape).background(Color(0x1A22D3EE)).border(1.dp, Cyan.copy(alpha = .3f), shape).padding(16.dp), content = content)
}

@Composable
fun AuraApp() {
    val ctx = LocalContext.current
    val p = remember { Prefs(ctx) }
    val st by AuraBus.state.collectAsStateWithLifecycle()
    val lv by AuraBus.level.collectAsStateWithLifecycle()
    val on by AuraBus.running.collectAsStateWithLifecycle()
    val log by AuraBus.log.collectAsStateWithLifecycle()
    var showSettings by rememberSaveable { mutableStateOf(false) }
    val hud by produceState("") {
        while (true) {
            val b = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val pct = b?.let { it.getIntExtra("level", 0) * 100 / it.getIntExtra("scale", 100) } ?: 0
            val net = if (ctx.getSystemService(ConnectivityManager::class.java).activeNetwork != null) "ONLINE" else "OFFLINE"
            value = "${LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"))}   BAT $pct%   $net"
            delay(5_000)
        }
    }
    val ask = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[Manifest.permission.RECORD_AUDIO] == true) ContextCompat.startForegroundService(ctx, Intent(ctx, AuraService::class.java))
    }
    fun toggle() {
        if (on) ctx.startService(Intent(ctx, AuraService::class.java).setAction("STOP"))
        else ask.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS))
    }

    Box(Modifier.fillMaxSize().background(Ink).systemBarsPadding()) {
        if (showSettings) SettingsScreen(p) { showSettings = false }
        else BoxWithConstraints(Modifier.fillMaxSize().padding(20.dp)) {
            val core: @Composable (Modifier) -> Unit = { m ->
                Column(m, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Orb(st, lv, Modifier.fillMaxWidth().weight(1f))
                    Text(st.label, color = Cyan, fontSize = 20.sp, letterSpacing = 6.sp)
                }
            }
            val side: @Composable (Modifier) -> Unit = { m ->
                Glass(m) {
                    Text(hud, color = Cyan, fontSize = 14.sp)
                    Spacer(Modifier.height(12.dp))
                    Text("Recent commands", color = Color.Gray, fontSize = 12.sp)
                    Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())) {
                        if (log.isEmpty()) Text("Say \"${p.s("wake", "Hey AURA")}\" to begin.", color = Color.Gray, fontSize = 14.sp)
                        log.forEach { Text(it, color = Color(0xFFCFF8FF), fontSize = 14.sp, modifier = Modifier.padding(vertical = 3.dp)) }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Button({ toggle() }, colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Ink)) {
                            Text(if (on) "Stop AURA" else "Start AURA")
                        }
                        OutlinedButton({ showSettings = true }) { Text("Settings") }
                    }
                }
            }
            if (maxWidth > maxHeight) Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                core(Modifier.weight(1.4f).fillMaxHeight()); side(Modifier.weight(1f).fillMaxHeight())
            } else Column(verticalArrangement = Arrangement.spacedBy(20.dp)) {
                core(Modifier.weight(1.3f).fillMaxWidth()); side(Modifier.weight(1f).fillMaxWidth())
            }
        }
    }
}

@Composable
fun Orb(st: AuraState, level: Float, mod: Modifier) {
    val tr = rememberInfiniteTransition(label = "orb")
    val spin by tr.animateFloat(0f, 360f, infiniteRepeatable(tween(16000, easing = LinearEasing)), label = "spin")
    val pulse by tr.animateFloat(0.94f, 1.06f, infiniteRepeatable(tween(1600), RepeatMode.Reverse), label = "pulse")
    val amp by animateFloatAsState(
        when (st) { AuraState.LISTENING -> level; AuraState.RESPONDING -> 0.55f; AuraState.THINKING -> 0.25f; else -> 0.08f }, label = "amp")
    Canvas(mod) {
        val c = center
        val r = size.minDimension / 2
        drawCircle(Brush.radialGradient(listOf(Cyan.copy(alpha = .6f), Cyan.copy(alpha = .1f), Color.Transparent), c, r * .6f * pulse), r * .6f * pulse, c)
        drawCircle(Color.White.copy(alpha = .85f), r * .09f * pulse, c)
        drawCircle(Cyan.copy(alpha = .3f), r * .66f, c, style = Stroke(2f))
        drawArc(Cyan.copy(alpha = .7f), spin, 70f, false, Offset(c.x - r * .94f, c.y - r * .94f), Size(r * 1.88f, r * 1.88f), style = Stroke(3f, cap = StrokeCap.Round))
        drawArc(Cyan.copy(alpha = .4f), 180f - spin * 1.5f, 40f, false, Offset(c.x - r * .58f, c.y - r * .58f), Size(r * 1.16f, r * 1.16f), style = Stroke(2f, cap = StrokeCap.Round))
        for (i in 0 until 72) {
            val a = i * (2 * PI.toFloat() / 72)
            val w = .5f + .5f * sin(i * .9f + Math.toRadians(spin * 3.0).toFloat())
            val d = Offset(cos(a), sin(a))
            drawLine(Cyan.copy(alpha = .8f), c + d * (r * .72f), c + d * (r * (.74f + .2f * amp * w)), 3f, StrokeCap.Round)
        }
    }
}

@Composable
fun Field(p: Prefs, k: String, label: String, d: String = "", secret: Boolean = false) {
    var v by remember { mutableStateOf(p.s(k, d)) }
    OutlinedTextField(v, { v = it; p.put(k, it) }, label = { Text(label) }, singleLine = true, modifier = Modifier.fillMaxWidth(),
        visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None)
}

@Composable
fun SettingsScreen(p: Prefs, close: () -> Unit) {
    val ctx = LocalContext.current
    var mem by remember { mutableStateOf(p.b("memory")) }
    var gen by remember { mutableIntStateOf(0) }
    fun open(action: String, pkg: Boolean = false) =
        ctx.startActivity(Intent(action).apply { if (pkg) data = Uri.parse("package:${ctx.packageName}") })
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Settings", color = Cyan, fontSize = 22.sp)
        Field(p, "wake", "Wake phrase", "hey aura")
        Field(p, "lang", "Speech language (BCP-47)", "en-IN")
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Text("Assistant memory", color = Color.White)
            Switch(mem, { mem = it; p.put("memory", it) })
        }
        if (mem) {
            key(gen) { Field(p, "name", "Preferred name"); Field(p, "subjects", "Study subjects") }
            OutlinedButton({ p.clearMemory(); gen++ }) { Text("Clear memory") }
        }
        Field(p, "apiUrl", "AI endpoint (HTTPS)", "https://api.anthropic.com/v1/messages")
        Field(p, "model", "AI model", "claude-sonnet-5-5")
        Field(p, "apiKey", "API key", secret = true)
        OutlinedButton({ open(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS) }) { Text("Battery optimisation") }
        OutlinedButton({ open(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, true) }) { Text("Allow opening apps from the background") }
        Button(close) { Text("Back") }
    }
}
