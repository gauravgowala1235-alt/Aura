# Build AURA APK on GitHub

1. Create a new GitHub repository.
2. Upload **all contents of this folder** to the repository root, including `.github/workflows/build-aura.yml`.
3. Open **Actions** in GitHub.
4. Select **Build AURA APK** and choose **Run workflow** (or push a commit to trigger it automatically).
5. After the workflow finishes, download **aura-debug-apk** from the workflow run's Artifacts section.
6. The APK file is `app-debug.apk`.

The project uses Java 17, Gradle 8.9, Android Gradle Plugin 8.5.2, compileSdk 35, minSdk 26, and targetSdk 35.
